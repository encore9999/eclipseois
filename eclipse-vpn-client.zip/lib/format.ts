export function formatBytes(bytes: number, perSecond = false): string {
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  let v = Math.max(0, bytes)
  let i = 0
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024
    i += 1
  }
  const num = v < 10 && i > 0 ? v.toFixed(1) : Math.round(v).toString()
  return `${num} ${units[i]}${perSecond ? '/s' : ''}`
}

export function formatDuration(ms: number): string {
  const total = Math.floor(ms / 1000)
  const h = Math.floor(total / 3600)
  const m = Math.floor((total % 3600) / 60)
  const s = total % 60
  const pad = (n: number) => n.toString().padStart(2, '0')
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`
}

// Country code -> flag emoji (used only as a small regional chip, not an icon).
export function regionFlag(code?: string): string {
  if (!code || code.length !== 2) return '🌐'
  const base = 0x1f1e6
  return String.fromCodePoint(
    ...code
      .toUpperCase()
      .split('')
      .map((c) => base + (c.charCodeAt(0) - 65)),
  )
}
